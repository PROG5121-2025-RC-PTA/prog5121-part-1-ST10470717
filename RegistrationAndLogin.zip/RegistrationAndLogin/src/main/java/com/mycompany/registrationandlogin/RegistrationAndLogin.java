/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.registrationandlogin;
import java.util.Scanner;
/**
 *
 * @author Mpilo Dladla ST10470717
 */

public class RegistrationAndLogin {
   public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); 
         
 
       // User enters username
        System.out.println("Create a username:");
        String createUsername = scanner.nextLine();
      
       //Checking username criteria 
       
       if (createUsername.contains("_") && createUsername.length() <=  6) {  
       System.out.println("Username successfully captured ");
       } else {
           System.out.println("Username is not correctly formatted, please ensure that your "
                   + "username contains an underscore and is no longer than five characters in length ");
           
           return;
           
       }
       // Username creates password 
       System.out.println("Create password");
        String createPassword = scanner.nextLine();
        
       // Checking Password criteria 
       if (isValidPassword(createPassword)) {
            System.out.println("Password successfully captured.");
        } else {
            System.out.println("Password is not correctly formatted. Please ensure that the password "
                    + "contains at least 8 characters, a capital letter, a number, and a special character.");
            
            return;
        }
       // User enters cell number 
   
        System.out.println("Enter phone number, eg +27123456789.");
        String cellNumber =  scanner.nextLine();
     
        if (isValidPhoneNumber(cellNumber)) {
            System.out.println("Cell phone number successfully captured");
        } else {
            System.out.println("Cell phone number incorrectly formatted or does "
                    + "not contain international code");
            
            return; 
        }
        System.out.println("Registration complete" + createUsername + "!" );
        
        
        //Login 
        System.out.println("Login");
        System.out.println("Enter username");
        String loginUsername = scanner.nextLine(); 
        
        System.out.println("Enter Password");
        String loginPassword = scanner.nextLine(); 
        
        String loginStatus = returnLoginStatus(createUsername, createPassword, loginUsername, loginPassword);
        System.out.println(loginStatus);

        scanner.close();
   }

        // Method that checks Password criteria 
         public static boolean isValidPassword(String password) {
        return password.length() >= 8 &&                   // At least 8 characters long 
               password.matches(".*[A-Z].*") &&       // Contain at least one capital letter 
               password.matches(".*\\d.*") &&         // Contain  at least one digit
               password.matches(".*[!@#$%^&*()-+=<>?].*");  // Contain at least one special character
         }
   
        // Method that checks username criteria 
       public static boolean checkUsername(String username) {
            return username.contains("_") && username.length() <= 5;
       }
        //Method to validate phone number
        public static boolean isValidPhoneNumber(String number) {
            return number.matches("\\+27\\d{9}"); // So that the user can input cell number using +27.. format
        }
  
       // Login status 
       public static String returnLoginStatus(String registeredUsername, String registeredPassword,
                                           String inputUsername, String inputPassword) {
        // Login Method 
        if (registeredUsername.equals(inputUsername) && registeredPassword.equals(inputPassword)) {
        return "Welcome" + registeredUsername + "it is great to see you again." ;
        } else {
            return "Username or pasword incorrect, please try again";
        }
     
        }
       }





    

